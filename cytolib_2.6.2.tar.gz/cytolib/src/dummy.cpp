void dummy_RProtobuf_fun()
{
}
