/*
 * convertRawBytes.h
 *
 *  Created on: Nov 24, 2015
 *      Author: wjiang2
 */

#ifndef CONVERTRAWBYTES_H_
#define CONVERTRAWBYTES_H_

typedef unsigned char BYTE;
typedef std::vector<BYTE> BYTES;



#endif /* CONVERTRAWBYTES_H_ */
